<?php return array (
  'Build-Date' => 'Fri, 01 May 20 17:59:55 +0000',
  'Phrases-Version' => '1.14',
  'Build-Version' => 'v1.14-1-ge5d3c8f',
  'Build-Major-Version' => '1.14',
  'Language' => 'es_MX',
  'Id' => 'lang:es_MX',
  'Last-Revision' => '2020-04-28 14:50',
  'Version' => 158808,
);